#ifndef QUITTUNG_H
#define QUITTUNG_H


class quittung
{
public:
    quittung();
};

#endif // QUITTUNG_H