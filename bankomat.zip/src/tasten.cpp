#include "tasten.h"

tasten::tasten(bankautomat atm): atm(atm){

}

void tasten::abbrechen(){
	
}
void tasten::letztes_zeichen_loeschen(){
	
}
void tasten::bestaetigen(){
	
}
void tasten::hinweise_aufrufen(){
}
void tasten::beitrag_eingeben(){
	
}
void tasten::pin_eingabe(){
	
}
