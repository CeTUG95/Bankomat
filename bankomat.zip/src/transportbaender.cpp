#include "transportbaender.h"

transportbaender::transportbaender(bankautomat atm): atm(atm){

}

void transportbaender::geldtransport(){

}
// Hat auf unseren code keinen effekt !
