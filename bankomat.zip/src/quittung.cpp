#include "quittung.h"

quittung::quittung(){

}
