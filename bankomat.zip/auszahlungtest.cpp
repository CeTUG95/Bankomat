#include "auszahlungtest.h"

auszahlungtest a1(40,1000);
